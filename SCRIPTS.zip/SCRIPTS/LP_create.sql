-- CREATE TABLE LP CORRESPONDING TO FILE LIST-PLANETS.CSV
create table LP (
	lp_id integer not null primary key,
	lp_name varchar(40),
	x float,
	y float
);
