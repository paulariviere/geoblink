-- IMPORTS DATA FROM PLANET-AFFINITY.CSV INTO PA
COPY PA FROM '/home/paula/VARIOS/GEOBLINK/planet-affinity.csv' delimiter ',' CSV;
