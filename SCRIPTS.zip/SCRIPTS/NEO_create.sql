-- CREATE TABLE NEO TO STORE THE NUMBER OF EVIL OUTPOSTS NEAR A GIVEN ONE
create table NEO (
	neo_id  integer not null PRIMARY KEY,
	neo_num integer
);
