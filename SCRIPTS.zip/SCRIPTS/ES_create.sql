-- CREATE TABLE ES TO STORE THE EVIL STATIONS
create table ES (
	es_id  integer not null PRIMARY KEY,
	es_x float,
	es_y float,
	es_f1 integer,
	es_f2 integer
);
