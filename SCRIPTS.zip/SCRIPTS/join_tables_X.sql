-- NEW TABLE LP_DP1: JOINS DATA FROM DATA-PLANETS1.CSV AND LIST-PLANETS.CSV
-- JOIN BY ID
select *
into LP_DP1
from LP
inner join DP1 on dp1.dp1_id = lp.lp_id;

-- NEW TABLE LP_DP1_DP2: JOINS DATA FROM LP_DP1 AND DATA-PLANETS2.CSV
-- JOIN BY NAME
select *
into LP_DP1_DP2
from LP_DP1
inner join DP2 on lp_dp1.lp_name=dp2.dp2_name;

-- REMOVE DUPLICATED ID
alter table LP_DP1_DP2 drop column dp1_id; 

-- REMOVE DUPLICATED NAME
alter table LP_DP1_DP2 drop column dp2_name;

-- REMOVE LINES OF THE JOINT TABLE WHERE THERE ARE MISSING VALUES
delete from LP_DP1_DP2 where not (lp_dp1_dp2 is not null);

-- COPY THE GENERATED TABLE INTO THE FEATURE TABLE X, ORDERING BY PLANET ID
select * into X from LP_DP1_DP2 order by lp_id asc;

-- REMOVE COLUMNS ID AND NAME FROM X, SINCE THEY ARE NOT FEATURES
alter table X drop column lp_id;
alter table X drop column lp_name;

-- REMOVE TEMP TABLE
drop table LP_DP1;

