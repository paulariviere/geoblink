-- COPIES PLANET IDENTIFICATIONS INTO THE NEAR EVIL OUTPOSTS TABLE NEO
insert into neo (neo_id) select es_id from es
