-- COPIES PLANET IDENTIFICATIONS INTO THE NEAR PLANETS TABLE NP
insert into np (np_id) values (select lp_id from lp_dp1_dp2);
