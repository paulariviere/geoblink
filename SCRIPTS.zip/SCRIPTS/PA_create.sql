-- CREATE TABLE PA CORRESPONDING TO FILE PLANET-AFFINITY.CSV
create table PA (
pa_id integer not null primary key,
pa_affinity float)

