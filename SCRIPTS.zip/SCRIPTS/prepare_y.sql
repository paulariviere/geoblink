-- GENERATE TARGET TABLE Y FROM ID AND AFFINITY
-- JOINS PA AND LP_DP1_DP2 BY ID
select pa.pa_id,pa.pa_affinity
into Y
from PA 
inner join LP_DP1_DP2 on pa.pa_id = lp_dp1_dp2.lp_id
order by pa.pa_id asc;

-- REMOVE UNNEEDED COLUMN ID
alter table y drop column pa_id;

