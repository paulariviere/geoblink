-- CREATE TABLE NP TO STORE THE NUMBER OF NEAR PLANETS FOR EACH PLANET
create table NP (
	np_id  integer not null PRIMARY KEY,
	np_num integer
);
